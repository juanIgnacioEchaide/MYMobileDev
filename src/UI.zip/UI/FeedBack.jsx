import React, { useState } from 'react';
import { View, Text, Button, Image, TextInput, ScrollView, FlatList, Modal,TouchableOpacity } from 'react-native';
import AlerRight from './AlertRight.jsx';
import AlertWrong from './AlertWrong.jsx';

const FeedBack = props => {
    return (
        <View>
      {/*       {lacorrecta==laelegida?<AlertRight/>:<AlertWrong/>} */}
        
        </View>
    );
};


export default FeedBack;