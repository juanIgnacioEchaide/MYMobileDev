import React, { useState } from 'react';
import { View, Text, Button, Image, TextInput, ScrollView, FlatList, Modal,TouchableOpacity } from 'react-native';

const AlertRight = props => {
    return (
        <View>
           <Text>Ok, baby</Text> 
        </View>
    );
};


export default AlertRight;